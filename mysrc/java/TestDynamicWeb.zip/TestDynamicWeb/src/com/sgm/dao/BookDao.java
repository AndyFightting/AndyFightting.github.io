package com.sgm.dao;

public interface BookDao {

}
