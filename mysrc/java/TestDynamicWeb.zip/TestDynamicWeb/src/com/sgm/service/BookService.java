package com.sgm.service;

public interface BookService {
	public void printMsg();
}
