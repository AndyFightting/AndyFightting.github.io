package com.sgm.bean;

public class Book {

}
